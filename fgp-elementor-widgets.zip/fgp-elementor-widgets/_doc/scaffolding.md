# Scaffolding

```
fgp-elementor-widgets/
│
├── widgets/
│   ├── hello/
│   │   ├── class-fgp-hello-widget.php
│   │   └── hello.css
│   ├── other/
│   │   ├── class-fgp-other-widget.php
│   │   └── other.css
│
└── fgp-elementor-widgets.php

```
